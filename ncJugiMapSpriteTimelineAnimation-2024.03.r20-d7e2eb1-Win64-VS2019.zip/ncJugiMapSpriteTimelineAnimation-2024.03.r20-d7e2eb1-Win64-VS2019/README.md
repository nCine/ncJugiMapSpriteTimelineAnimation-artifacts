[![Linux](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/workflows/Linux/badge.svg)](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/actions?workflow=Linux)
[![macOS](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/workflows/macOS/badge.svg)](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/actions?workflow=macOS)
[![Windows](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/workflows/Windows/badge.svg)](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/actions?workflow=Windows)
[![MinGW](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/workflows/MinGW/badge.svg)](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/actions?workflow=MinGW)
[![Emscripten](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/workflows/Emscripten/badge.svg)](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/actions?workflow=Emscripten)
[![Android](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/workflows/Android/badge.svg)](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/actions?workflow=Android)
[![CodeQL](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/workflows/CodeQL/badge.svg)](https://github.com/nCine/ncJugiMapSpriteTimelineAnimation/actions?workflow=CodeQL)

# ncJugiMapSpriteTimelineAnimation
A nCine port of the [JugiMap](http://jugimap.com) [SpriteTimelineAnimation](https://github.com/Jugilus/JugiMapFramework) demo by [Jugilus](https://github.com/Jugilus).

The JugiMap Framework is distributed under the [MIT License](https://github.com/Jugilus/JugiMapFramework/blob/master/LICENSE) and is Copyright (c) 2019 Jugilus.
