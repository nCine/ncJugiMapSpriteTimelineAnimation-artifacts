# Data files for the *ncJugiMapSpriteTimelineAnimation* project

## Icons

- The images in the `icons` folder have been created by Angelo Theodorou for the ncJugiMapSpriteTimelineAnimation project assembling together images from the media folder of https://github.com/Jugilus/JugiMapFramework
